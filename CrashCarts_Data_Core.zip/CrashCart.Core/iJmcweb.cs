﻿using System;
using System.Buffers;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CrashCarts.Core
{
    public class iSciPat
    {
        public int id { get; set; }
        public string Cart_id { get; set; }
        public string Needle_id { get; set; }
        public string Backboard_id { get; set; }
        public string O2tank_id { get; set; }
        public string Tray1_id { get; set; }
        public string Tray2_id { get; set; }
        public string Tray3_id { get; set; }
        public string Tray4_id { get; set; }
        public string Location_id { get; set; }
        public string Createdttm { get; set; }
        public string Createby { get; set; }
        public string Moddttm { get; set; }
        public string Modby { get; set; }
        public Boolean? Active { get; set; }
        public int chkout { get; set; }
        public string chkout_dttm { get; set; }
        public string chkout_by { get; set; }

    }

    public class iTray
    {
        public int id { get; set; }
        public int tray_slot { get; set; }
        public string tray_type { get; set; }
        public string barcode { get; set; }
    }

    public class iTrayActivity
    {
        public int id { get; set; }
        public int tray_id { get; set; }
        public int tray_item_id { get; set; }
        public string barcode { get; set; }
        public string createby { get; set; }
        public DateTime? createdttm { get; set; }
        public int? tray_status { get; set; }


    }

    public class iTrayItem
    {
        public int id { get; set; }
        public string tray_type { get; set; }
        public int? item_sort { get; set; }
        public string item { get; set; }
        public string catalog_nbr { get; set; }
        public string item_descr { get; set; }
        public int? qty { get; set; }
    }

    public class iTrayActivityTemp
    {
        public int id { get; set; }
        public int tray_id { get; set; }
        public string tray_type { get; set; }
        public string item1 { get; set; }
        public string item2 { get; set; }
        public string item3 { get; set; }
        public string item4 { get; set; }
        public string item5 { get; set; }
        public string item6 { get; set; }
        public string item7 { get; set; }
        public string item8 { get; set; }
        public string item9 { get; set; }
        public string item10{ get; set; }
        public string item11 { get; set; }
        public string item12 { get; set; }
        public string item13 { get; set; }
        public string item14 { get; set; }
        public string item15 { get; set; }
        public string item16 { get; set; }
        public string item17 { get; set; }
        public string item18 { get; set; }
        public string item19 { get; set; }
        public string item20 { get; set; }
        public string item21 { get; set; }
        public string item22 { get; set; }
        public string item23 { get; set; }
        public string item24 { get; set; }
        public string item25 { get; set; }
        public string item26 { get; set; }
        public string item27 { get; set; }
        public string item28 { get; set; }
        public string item29 { get; set; }
        public string item30 { get; set; }
        public string createby { get; set; }
        public DateTime? createdttm { get; set; }
        public int? tray_status { get; set; }


    }

    public class iTrayBuild
    {
        public int id { get; set; }
        public int tray_id { get; set; }
        public string tray_type { get; set; }
        public int tray_item_id { get; set; }
        public string tray_item { get; set; }
        public string tray_catalog_nbr { get; set; }
        public int? tray_item_qty { get; set; }
        public string tray_item_desc { get; set; }
        public string tray_barcode { get; set; }
        public string tray_lot_nbr { get; set; }
        public DateTime? tray_exp_date { get; set; }
        public bool? chk_out { get; set; }
        public string chk_out_by { get; set; }
        public DateTime? chk_out_dttm { get; set; }
        public DateTime? create_dttm { get; set; }
        public string create_by { get; set; }
        public DateTime? modify_dttm { get; set; }
        public string modify_by { get; set; }
        public int? tray_status { get; set; }
        public DateTime? tray_status_dttm { get; set; }
        public string tray_status_by { get; set; }
        public bool? db_lock { get; set; }


    }


    public class iSciPhone
    {

        public int Id { get; set; }
        public int Ptid { get; set; }
        public int? Ph_seq { get; set; }
        public int? Ph_type { get; set; }
        public string Ph_no { get; set; }
        public int? Ph_ext { get; set; }
        public string Ph_add_info { get; set; }
        public Boolean? Ph_text_consent { get; set; }
        public DateTime? Ph_date { get; set; }
        public string Ph_by { get; set; }

    }

    public class iSciMsg
    {
        public int Id { get; set; }
        public int Pat_id { get; set; }
        public int Msg_seq { get; set; }
        public string Msg_init { get; set; }
        public int Msg_cb_day { get; set; }
        public int Msg_cb_time { get; set; }
        public DateTime Msg_date { get; set; }
        public string Msg_by { get; set; }
    }

    public class iSciProc
    {
        public int Id { get; set; }
        public int Ptid { get; set; }
        public int Proc_seq { get; set; }
        public int Proc_type { get; set; }
        public string Proc_desc { get; set; }
        public DateTime Proc_date { get; set; }
        public string Proc_by { get; set; }
    }

    public class iSciIns
    {
        public string Id { get; set; }
        public string Ptid { get; set; }
        public string Ins_seq { get; set; }
        public string Ins_desc { get; set; }
        public string Ins_date { get; set; }
        public string Ins_by { get; set; }
    }

    public class iSciOrd
    {
        public string Id { get; set; }
        public string Ptid { get; set; }
        public string Ord_seq { get; set; }
        public string Ord_stat { get; set; }
        public string Ord_phys { get; set; }
        public string Ord_script { get; set; }
        public string Ord_script_source { get; set; }
        public string Ord_date { get; set; }
        public string Ord_by { get; set; }
    }

    public class iSciComment
    {
        public string Id { get; set; }
        public string Ptid { get; set; }
        public string Cmt_seq { get; set; }
        public string Cmt_text { get; set; }
        public string Cmt_date { get; set; }
        public string Cmt_by { get; set; }
    }

    public class iSciTest
    {
        public int id { get; set; }
        public string test_column { get; set; }

    }

    public class iSciAud
    {
        public int Id { get; set; }
        public string Chkout_by { get; set; }
        public DateTime? Chkout_dttm { get; set; }
        public DateTime? Chkin_dttm { get; set; }

    }



}