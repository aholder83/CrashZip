﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CrashCarts.Core
{
    public enum YesNo
    {
        No = 0,
        Yes = 1,
        Hold = 2
    }

    [DefaultValue(No)]
    public enum Opt1
    {

        [Display(Name = "Not Reviewed")]
        No = 0,
        [Display(Name = "Scheduled")]
        Yes = 1,
        [Display(Name = "No Answer - Callback")]
        Call = 7,
        [Display(Name = "Busy - Callback")]
        Bus = 8,
        [Display(Name = "Cancel Appointment Request")]
        Cxl = 6

    }


    [DefaultValue(No)]
    public enum Opt2
    {

        [Display(Name = "Not Reviewed")]
        No = 0,
        [Display(Name = "Completed/Scheduled")]
        Yes = 1,
        [Display(Name = "Left Message")]
        Call = 2,
        [Display(Name = "Other")]
        Oth = 3


    }


    [DefaultValue(No)]
    public enum Escal1
    {

        [Display(Name = "Normal")]
        No = 0,
        [Display(Name = "Medium")]
        Me = 1,
        [Display(Name = "High")]
        Hi = 2

    }

    [DefaultValue(No)]
    public enum EscalNorm
    {
        [Display(Name = "Default/Standard")]
        No = 0

    }

    [DefaultValue(No)]
    public enum EscalMed
    {
        [Display(Name = "Patient Called more than 1x")]
        No = 0

    }

    [DefaultValue(No)]
    public enum EscalHigh
    {
        [Display(Name = "Patient Called more than 2x")]
        No = 0,
        [Display(Name = "VIP")]
        VIP = 1,
        [Display(Name = "Internal Scheduling request")]
        Frm = 2

    }



    [DefaultValue(LA)]
    public enum PhType
    {


        [Display(Name = "Landline")]
        LA = 1,
        [Display(Name = "Cell Phone")]
        CE = 2,
        [Display(Name = "Email")]
        EM = 3

    }



    public enum genderType
    {
        [Display(Name = "Male")]
        M = 1,
        [Display(Name = "Female")]
        F = 2,
        [Display(Name = "Unknown")]
        NA = 3

    }

    [DefaultValue(FL)]
    public enum stateType
    {
        [Display(Name = "Other")]
        OT = 0,
        [Display(Name = "Alabama")]
        AL = 1,
        [Display(Name = "Alaska")]
        AK = 2,
        [Display(Name = "Arizona")]
        AZ = 3,
        [Display(Name = "Arkansas")]
        AR = 4,
        [Display(Name = "California")]
        CA = 5,
        [Display(Name = "Colorado")]
        CO = 6,
        [Display(Name = "Connecticut")]
        CT = 7,
        [Display(Name = "Delaware")]
        DE = 8,
        [Display(Name = "Florida")]
        FL = 9,
        [Display(Name = "Georgia")]
        GA = 10,
        [Display(Name = "Hawaii")]
        HI = 11,
        [Display(Name = "Idaho")]
        ID = 12,
        [Display(Name = "Illinois")]
        IL = 13,
        [Display(Name = "Indiana")]
        IN = 14,
        [Display(Name = "Iowa")]
        IA = 15,
        [Display(Name = "Kansas")]
        KS = 16,
        [Display(Name = "Kentucky")]
        KY = 17,
        [Display(Name = "Louisiana")]
        LA = 18,
        [Display(Name = "Maine")]
        ME = 19,
        [Display(Name = "Maryland")]
        MD = 20,
        [Display(Name = "Massachusetts")]
        MA = 21,
        [Display(Name = "Michigan")]
        MI = 22,
        [Display(Name = "Minnesota")]
        MN = 23,
        [Display(Name = "Mississippi")]
        MS = 24,
        [Display(Name = "Missouri")]
        MO = 25,
        [Display(Name = "Montana")]
        MT = 26,
        [Display(Name = "Nebraska")]
        NE = 27,
        [Display(Name = "Nevada")]
        NV = 28,
        [Display(Name = "New Hampshire")]
        NH = 29,
        [Display(Name = "New Jersey")]
        NJ = 30,
        [Display(Name = "New Mexico")]
        NM = 31,
        [Display(Name = "New York")]
        NY = 32,
        [Display(Name = "North Carolina")]
        NC = 33,
        [Display(Name = "North Dakota")]
        ND = 34,
        [Display(Name = "Ohio")]
        OH = 35,
        [Display(Name = "Oklahoma")]
        OK = 36,
        [Display(Name = "Oregon")]
        OR = 37,
        [Display(Name = "Pennsylvania")]
        PA = 38,
        [Display(Name = "Rhode Island")]
        RI = 39,
        [Display(Name = "South Carolina")]
        SC = 40,
        [Display(Name = "South Dakota")]
        SD = 41,
        [Display(Name = "Tennessee")]
        TN = 42,
        [Display(Name = "Texas")]
        TX = 43,
        [Display(Name = "Utah")]
        UT = 44,
        [Display(Name = "Vermont")]
        VT = 45,
        [Display(Name = "Virginia")]
        VA = 46,
        [Display(Name = "Washington")]
        WA = 47,
        [Display(Name = "West Virginia")]
        WV = 48,
        [Display(Name = "Wisconsin")]
        WI = 49,
        [Display(Name = "Wyoming")]
        WY = 50


    }




}
