﻿using System;
using Microsoft.EntityFrameworkCore;
using CrashCarts.Core;
namespace CrashCarts.Data
{
    public class AppDbContext : DbContext
    {


        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {

        }
        public DbSet<iSciPat> scs_cartassemb { get; set; }
        public DbSet<iTrayActivity> cc_tray_activity { get; set; }
        public DbSet<iTrayActivityTemp> cc_tray_activity_temp { get; set; }
        public DbSet<iTray> cc_tray { get; set; }
        public DbSet<iTrayItem> cc_tray_item { get; set; }
        public DbSet<iTrayBuild> cc_tray_build { get; set; }
        public DbSet<iSciPhone> tblSCI_PHONE { get; set; }
        public DbSet<iSciMsg> tblSCI_MSG { get; set; }
        public DbSet<iSciProc> tblSCI_PROC { get; set; }
        public DbSet<iSciIns> tblSCI_INS { get; set; }
        public DbSet<iSciOrd> tblSCI_ORD { get; set; }
        public DbSet<iSciComment> tblSCI_COMMENT { get; set; }
        public DbSet<iSciTest> tblSCI_TEST { get; set; }
        public DbSet<iSciAud> tblSCI_AUDIT { get; set; }
    }



}