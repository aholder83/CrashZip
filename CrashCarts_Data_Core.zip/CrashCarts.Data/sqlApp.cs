﻿using System.Collections.Generic;
using CrashCarts.Core;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System;


namespace CrashCarts.Data
{
    public class sqlApp : iApp
    {

        private readonly AppDbContext db;
        

        public sqlApp(AppDbContext db)
        {
            this.db = db;
        }



        public IEnumerable<iSciPat> GetAllPatients()
        {
            //var stat = new bool?[] {true};
            var query = from r in db.scs_cartassemb

                        //where stat.Contains(r.Active)
                        //where Convert.ToInt32(r.Id) > 0
                        //where /*r.list == list &&*/ r.chkout == 0 && r.appt_status == 0 && (r.ntassign == null || r.ntassign == uid)
                        orderby r.id
                        //orderby r.age descending
                        select r;
            return query;
        }

        public iSciPat GetByIdPatients(int id)
        {
            return db.scs_cartassemb.Find(id);

        }

        //public iSciPhone GetByIdPhone(int id)
        //{
        //  return db.tblSCI_PHONE.Find(id);
        //}

        public iSciPat Update(iSciPat updatediSciPat)
        {
            var entity = db.scs_cartassemb.Attach(updatediSciPat);
            entity.State = EntityState.Modified;
            return updatediSciPat;
        }

        public IEnumerable<iSciPhone> GetByIdPhone(int id)
        {
            var query = from r in db.tblSCI_PHONE
                        where Convert.ToInt32(r.Ptid) == id
                        //where /*r.list == list &&*/ r.chkout == 0 && r.appt_status == 0 && (r.ntassign == null || r.ntassign == uid)
                        orderby r.Ph_seq
                        //orderby r.age descending
                        select r;
            return query;
        }

        public iSciPat Insert(iSciPat insertedSciPat)
        {
            var entity = db.scs_cartassemb.Add(insertedSciPat);
            entity.State = EntityState.Added;
            return insertedSciPat;
        }

        public iSciPat Add(iSciPat newPat)
        {
            db.Add(newPat);
            return newPat;
        }

        public iSciTest Add(iSciTest AddediSciTest)
        {
            db.tblSCI_TEST.Add(AddediSciTest);
            return AddediSciTest;
        }

        public int Commit()
        {
            return db.SaveChanges();
        }

        public iSciPhone Add(iSciPhone newPhone)
        {
            db.Add(newPhone);
            return newPhone;
        }
        
        //public IEnumerable<iSciPat> GetDupPatients(string name, DateTime dob)
        //{
        //    var query = from r in db.scs_cartassemb
        //                    //where Convert.ToInt32(r.Id) > 0
        //                where r.Pt_fname == name && r.Pt_dob == dob

        //                select r;
        //    return query;
        //}


        //public IEnumerable<iSciPat> GetQueuePatients()
        //{
        //    var stat = new int?[] { null, 0, 3 };
        //    var query = (from r in db.scs_cartassemb
        //                     //where Convert.ToInt32(r.Id) > 0
        //                 where r.chkout == 0 && stat.Contains(r.Sci_status) || r.chkout == null && stat.Contains(r.Sci_status)
        //                 orderby r.Pt_ordstat descending, r.Pt_createdttm
        //                 //orderby r.age descending
        //                 select r).Take(25);
        //    return query;
        //}


        public IEnumerable<iSciPat> GetQueuePatients()
        {
            //var stat = new bool?[] { true};
            var query = from r in db.scs_cartassemb
                            //where Convert.ToInt32(r.Id) > 0
                        //where r.chkout == 0 && stat.Contains(r.Active) || r.chkout == null && stat.Contains(r.Active)
                        orderby r.Createdttm descending
                        //orderby r.age descending
                        select r;
            return query;
        }


        iSciPat iApp.GetDupPatients(string name, DateTime dob)
        {
            return db.scs_cartassemb.Find(name, dob);
        }


        public IEnumerable<iSciPat> Get25Queue()
        {
            var query = (GetQueuePatients()).Take(25);
            return query;
        }


        public int QueueCount()
        {
            int count = GetQueuePatients().Count();
            return count;
        }

     


        public IEnumerable<iTrayActivity> GetAllTrayActivity()
        {
            var query = from r in db.cc_tray_activity

                            //where stat.Contains(r.Active)
                            //where Convert.ToInt32(r.Id) > 0
                            //where /*r.list == list &&*/ r.chkout == 0 && r.appt_status == 0 && (r.ntassign == null || r.ntassign == uid)
                        orderby r.id
                        //orderby r.age descending
                        select r;
            return query;
        }

        //public IEnumerable<iTray> GetByIdTray(int id)
        //{
        //    var query = from r in db.cc_tray
        //                where Convert.ToInt32(r.id) == id
        //                select r;
        //    return query;
        //}

        public IEnumerable<iTray> GetByBarcodeTray(string bar = null)
        {

                              

            var query = from r in db.cc_tray
                        where string.IsNullOrEmpty(bar) || r.barcode == bar
                        select r;
            return query;
            //return query;
            
        }

        //public void GetByBarcodeTrayIdx (string bar = null)
        //{
        //    int id = (from r in db.cc_tray
        //              where string.IsNullOrEmpty(bar) || r.barcode == bar
        //              select r.id).First();

        //}


        public string BarcodeID()
        {
            var t = BarcodeID().ElementAtOrDefault(0);
            
                
                return t.ToString();
        }



        iTray iApp.ReturnTrayType(string barcode)
        {


            return db.cc_tray.Find(barcode);
            //var query = from r in db.cc_tray
            //            where r.barcode == barcode
            //            select r;
            //return query;
        }

        iTray iApp.GetByIdTray(int id)
        {
            return db.cc_tray.Find(id);
        }
        
        public IEnumerable<iTray> GetByBCTray(string bc = "ABC100")
        {
           
            var query = from r in db.cc_tray
                        where r.barcode == bc
                        select r;
            return query;
        }


        iTray iApp.ReturnTrayId(string barcode)
        {
            string bc = barcode;

            int trayid = (from e in db.cc_tray
                            where e.barcode == bc
                            select e.id).FirstOrDefault();
            //return trayid;
            return null;

        }

        public int GetByBarcodeTrayId(string bar = null)
        {
            int id = (from r in db.cc_tray
                      where string.IsNullOrEmpty(bar) || r.barcode.Substring(0,3) == bar.Substring(0,3)
                      select r.id).First();
            return id;
        }

        public IEnumerable<iTrayItem> GetAllItemsByType(string bc)
        {
            var query = from a in db.cc_tray_item
                        where a.tray_type == bc
                        select a;
            return query;
        }

        public iTrayActivity Add(iTrayActivity newTrayActivity)
        {   
                db.Add(newTrayActivity);
                return newTrayActivity;
        }

        public iTrayActivityTemp Add(iTrayActivityTemp newiTrayActivityTemp)
        {
            db.Add(newiTrayActivityTemp);
            return newiTrayActivityTemp;
        }

        public IEnumerable<iTrayBuild> GetTrayBuild(int id, string tray_type)
        {
            var query = from a in db.cc_tray_build
                        where a.tray_id==id && a.tray_type == tray_type
                        select a;
            return query;
        }

        public iTrayBuild Add(iTrayBuild newTrayBuild)
        {
            db.Add(newTrayBuild);
            return newTrayBuild;
        }

        public iTrayBuild Update(iTrayBuild updTrayBuild)
        {
            var entity = db.cc_tray_build.Attach(updTrayBuild);
            entity.State = EntityState.Modified;
                
            
            db.SaveChanges();
                return updTrayBuild;


        }
    }
}
