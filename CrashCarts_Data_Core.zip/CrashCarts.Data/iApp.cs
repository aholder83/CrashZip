﻿using System;
using System.Collections.Generic;
using System.Text;
using CrashCarts.Core;
using CrashCarts;
using System.Linq;

namespace CrashCarts.Data
{
    public interface iApp
    {

        IEnumerable<iSciPat> GetAllPatients();        
        IEnumerable<iTrayActivity> GetAllTrayActivity();
        iTray GetByIdTray(int id);
        IEnumerable<iTray> GetByBarcodeTray(string bar);
        int GetByBarcodeTrayId(string bar);
        string BarcodeID();
        iTray ReturnTrayType(string bc);
        iTray ReturnTrayId(string bc);
        iTrayActivity Add(iTrayActivity newTrayActivity);
        iTrayActivityTemp Add(iTrayActivityTemp newiTrayActivityTemp);
        IEnumerable<iTray> GetByBCTray(string bc);
        IEnumerable<iTrayItem> GetAllItemsByType(string bc);

        IEnumerable<iSciPat> GetQueuePatients();
        IEnumerable<iSciPat> Get25Queue();
        iSciPat GetDupPatients(string name, DateTime dob);
        iSciPat GetByIdPatients(int id);
        iSciPat Update(iSciPat updatediSciPat);
        iSciPat Add(iSciPat newPat);
        IEnumerable<iTrayBuild> GetTrayBuild(int id, string tray_type);
        iTrayBuild Add(iTrayBuild newTrayBuild);
        iTrayBuild Update(iTrayBuild updTrayBuild);
        //iSciPat GetAllPatients(int id);
        //IEnumerable<iSciPat> GetDupPatients(string name, DateTime dob);
        int QueueCount();
        int Commit();

    }



}



//iSciTest Add(iSciTest AddediSciTest);
//iSciPhone Add(iSciPhone newPhone);
//iSciPhone GetByIdPhone(int ptid);


//IEnumerable<iSciPhone> GetByIdPhone(int id);

